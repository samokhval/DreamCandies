#include "CSVConverter.h"
#include <QFile>
#include <QTextStream>
#include <iostream>

CSVConverter::CSVConverter(QObject *parent): QObject(parent)
{
    customerFileName = "CUSTOMER.CSV";
    invoiceFileName = "INVOICE.CSV";
    invoiceItemFileName = "INVOICE_ITEM.CSV";

    numberOfCustomers = 0;
}

bool CSVConverter::loadSampleFile(QString filename)
{
    bool isLoadedSuccefully = false;
    int  lineNo = 0;

    QFile file(filename);

    //try to open file for reading
    if (file.open(QIODevice::ReadOnly))
    {
        //file opened successfully
        QTextStream in(&file);

        //Reads the data up to the end of file
        while (!in.atEnd())
        {
            string customerCode = file.readLine().toStdString();
            //add all customers from sample file to customer list
            if ( lineNo > 0 )
                customersList.push_back(customerCode.substr(0, customerCode.size()-1));
            ++lineNo;
        }
        file.close();
        numberOfCustomers = customersList.size();
        isLoadedSuccefully = true;
    }
    return isLoadedSuccefully;
}

int CSVConverter::getNumberOfCustomers() const
{
    return numberOfCustomers;
}

bool CSVConverter::isCustomerFileFound()
{
    QFile test("./IN/"+customerFileName);
    return test.exists();
}

bool CSVConverter::isInvoiceFileFound()
{
    QFile test("./IN/"+invoiceFileName);
    return test.exists();
}

bool CSVConverter::isInvoiceItemFileFound()
{
    QFile test("./IN/"+invoiceItemFileName);
    return test.exists();
}

void CSVConverter::setCustomerFile(QString filename)
{
    customerFileName = filename;
}

void CSVConverter::setInvoiceFile(QString filename)
{
    invoiceFileName = filename;
}

void CSVConverter::setInvoiceItemFile(QString filename)
{
    invoiceItemFileName = filename;
}

void CSVConverter::startConvertation()
{
    int step = 1;
    emit changeProgressBar(step);

    processingCustomerCSV();
    emit changeProgressBar(++step);

    processingInvoiceCSV();
    emit changeProgressBar(++step);

    processingInvoiceItemsCSV();
    emit changeProgressBar(++step);
}

void CSVConverter::processingCustomerCSV()
{
    QFile inputFile("./IN/"+customerFileName);
    QFile outputFile("./OUT/NEW_"+customerFileName);

    int  lineNo = 0;

    //try to open input file for reading
    if (inputFile.open(QIODevice::ReadOnly))
    {
        //try to open output file for writing
        if (outputFile.open(QFile::WriteOnly|QFile::Truncate))
        {
            //files opened successfully
            QTextStream in(&inputFile);
            QTextStream stream(&outputFile);

            //Reads the data up to the end of file
            while (!in.atEnd())
            {
                QString data = inputFile.readLine();
                QStringList rowList = data.split(',');

                if ( lineNo > 0 )
                {
                    auto it = std::find(customersList.begin(), customersList.end(), rowList[0].toStdString());
                    if(it != customersList.end())
                    {
                        stream << rowList[0] << "," << rowList[1] << "," << rowList[2];
                    }
                }
                else //add header
                    stream << rowList[0] << "," << rowList[1] << "," << rowList[2];

                ++lineNo;
            }
        }
        inputFile.close();
        outputFile.close();
    }
}

void CSVConverter::processingInvoiceCSV()
{
    QFile inputFile("./IN/"+invoiceFileName);
    QFile outputFile("./OUT/NEW_"+invoiceFileName);

    int  lineNo = 0;

    if (inputFile.open(QIODevice::ReadOnly))
    {
        if (outputFile.open(QFile::WriteOnly|QFile::Truncate))
        {

            //files opened successfully
            QTextStream in(&inputFile);
            QTextStream stream(&outputFile);

            //Reads the data up to the end of file
            while (!in.atEnd())
            {
                QString data = inputFile.readLine();
                QStringList rowList = data.split(',');

                if ( lineNo > 0 )
                {
                    auto it = std::find(customersList.begin(), customersList.end(), rowList[0].toStdString());
                    if(it != customersList.end())
                    {
                        stream << rowList[0] << "," << rowList[1] << "," << rowList[2] << "," << rowList[3];
                        invoicesList.push_back(rowList[1].toStdString());
                    }
                }
                else //add header
                    stream << rowList[0] << "," << rowList[1] << "," << rowList[2] << "," << rowList[3];

                ++lineNo;
            }
        }
        inputFile.close();
        outputFile.close();
    }
}

void CSVConverter::processingInvoiceItemsCSV()
{
    QFile inputFile("./IN/"+invoiceItemFileName);
    QFile outputFile("./OUT/NEW_"+invoiceItemFileName);

    int  lineNo = 0;

    if (inputFile.open(QIODevice::ReadOnly))
    {
        if (outputFile.open(QFile::WriteOnly|QFile::Truncate))
        {
            //files opened successfully
            QTextStream in(&inputFile);
            QTextStream stream(&outputFile);

            //Reads the data up to the end of file
            while (!in.atEnd())
            {
                QString data = inputFile.readLine();
                QStringList rowList = data.split(',');

                if ( lineNo > 0 ) // starting from 2-nd row
                {
                    auto it = std::find(invoicesList.begin(), invoicesList.end(), rowList[0].toStdString());
                    if(it != invoicesList.end())
                    {
                        stream << rowList[0] << "," << rowList[1] << "," << rowList[2] << "," << rowList[3];
                    }
                }
                else //add header
                    stream << rowList[0] << "," << rowList[1] << "," << rowList[2] << "," << rowList[3];

                ++lineNo;
            }
        }
        inputFile.close();
        outputFile.close();
    }
}
