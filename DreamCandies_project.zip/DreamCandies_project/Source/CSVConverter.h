#ifndef CSVCONVERTER_H
#define CSVCONVERTER_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <string>
#include <list>

using namespace std;

class CSVConverter: public QObject
{
    Q_OBJECT
public:
    CSVConverter(QObject *parent=0);
    void startConvertation();
    bool loadSampleFile(QString filename);
    int getNumberOfCustomers() const;

    bool isCustomerFileFound();
    bool isInvoiceFileFound();
    bool isInvoiceItemFileFound();

    void setCustomerFile(QString filename);
    void setInvoiceFile(QString filename);
    void setInvoiceItemFile(QString filename);

signals:
    void changeProgressBar(int);

private:
    void processingCustomerCSV();
    void processingInvoiceCSV();
    void processingInvoiceItemsCSV();

    QString customerFileName;
    QString invoiceFileName;
    QString invoiceItemFileName;

    int numberOfCustomers;

    list<string> customersList;
    list<string> invoicesList;
};

#endif // CSVCONVERTER_H
