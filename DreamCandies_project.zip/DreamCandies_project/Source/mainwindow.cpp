#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QString>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    converter(new CSVConverter)
{
    ui->setupUi(this);
    ui->centralWidget->setFixedHeight(254);
    ui->centralWidget->setMaximumHeight(254);
    ui->centralWidget->setFixedWidth(469);
    ui->centralWidget->setMaximumWidth(469);

    QObject::connect(converter, SIGNAL(changeProgressBar(int)),
                        this, SLOT(on_progressBar_valueChanged(int)));

    ui->informLabel->setWordWrap(true);

    ui->checkCustomer->setChecked(converter->isCustomerFileFound());
    ui->checkInvoice->setChecked(converter->isInvoiceFileFound());
    ui->checkInvoiceItem->setChecked(converter->isInvoiceItemFileFound());

    ui->processingButton->setEnabled(false);

}

MainWindow::~MainWindow()
{
    delete ui;
    delete converter;
}

void MainWindow::on_pushButton_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open File"),
                                                    "./",
                                                    tr("CSV (*.csv)"));
    ui->lineEdit->setText(QFileInfo(fileName).fileName());
    if (converter->loadSampleFile(fileName))
    {
        ui->informLabel->setText("Successful loading");
        ui->processingButton->setEnabled(true);
    }
    else
    {
        ui->informLabel->setText("Cannot load the sample file");
    }
}

void MainWindow::on_processingButton_clicked()
{
    ui->informLabel->setText("");
    converter->startConvertation();
    ui->informLabel->setText("The processing done.");
}

void MainWindow::on_progressBar_valueChanged(int value)
{
    ui->progressBar->setValue(value);
}

void MainWindow::on_checkCustomer_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Please check the Customer.CSV file"),
                                                    "./",
                                                    tr("CSV (*.csv)"));
    converter->setCustomerFile(QFileInfo(fileName).fileName());
}

void MainWindow::on_checkInvoice_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Please check the Invoice.CSV file"),
                                                    "./",
                                                    tr("CSV (*.csv)"));
    converter->setInvoiceFile(QFileInfo(fileName).fileName());
}

void MainWindow::on_checkInvoiceItem_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Please check the Invoice_Item.CSV file"),
                                                    "./",
                                                    tr("CSV (*.csv)"));
    converter->setInvoiceItemFile(QFileInfo(fileName).fileName());
}

void MainWindow::on_closeButton_clicked()
{
    MainWindow::close();
}
